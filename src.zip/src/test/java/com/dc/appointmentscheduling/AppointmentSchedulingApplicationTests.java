package com.dc.appointmentscheduling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentSchedulingApplicationTests {

	@Test
	void contextLoads() {
	}

}
