package com.dc.appointmentscheduling.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class AppointmentScheduling {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer doaId;

    private  String poNumber;
    private String dateOfAppointment;

    @ManyToOne
    @JoinColumn(name = "dcNumber")
    private DistributionCenter distributionCenter;

    @ManyToMany
    @JoinColumn(name = "dcSlotId")
     private List<DcSlot>  dcSlot ;

    @OneToOne
    @JoinColumn(name = "truckId")
    private  Truck truck;

    public AppointmentScheduling() {
    }

    public AppointmentScheduling(Integer doaId, String poNumber, String dateOfAppointment, DistributionCenter distributionCenter, List<DcSlot> dcSlot, Truck truck) {
        this.doaId = doaId;
        this.poNumber = poNumber;
        this.dateOfAppointment = dateOfAppointment;
        this.distributionCenter = distributionCenter;
        this.dcSlot = dcSlot;
        this.truck = truck;
    }

    public Integer getDoaId() {
        return doaId;
    }

    public void setDoaId(Integer doaId) {
        this.doaId = doaId;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getDateOfAppointment() {
        return dateOfAppointment;
    }

    public void setDateOfAppointment(String dateOfAppointment) {
        this.dateOfAppointment = dateOfAppointment;
    }

    public DistributionCenter getDistributionCenter() {
        return distributionCenter;
    }

    public void setDistributionCenter(DistributionCenter distributionCenter) {
        this.distributionCenter = distributionCenter;
    }

    public List<DcSlot> getDcSlot() {
        return dcSlot;
    }

    public void setDcSlot(List<DcSlot> dcSlot) {
        this.dcSlot = dcSlot;
    }

    public Truck getTruck() {
        return truck;
    }

    public void setTruck(Truck truck) {
        this.truck = truck;
    }
}
